using System;

namespace Task_Killer
{
    public class Note
	{
        public string Name { get; set; }
		public DateTime Creationdate { get; set; }
		public string Text { get; set;}
	}
}